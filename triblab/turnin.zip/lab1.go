package triblab

import (
    "net/rpc"
    "net/http"
    "net"
    "fmt"
	"trib"
)

// Creates an RPC client that connects to addr.
func NewClient(addr string) trib.Storage {
    return &client{addr: addr}
}

// Serve as a backend based on the given configuration
func ServeBack(b *trib.BackConfig) error {
    e := rpc.Register(b.Store)
    if e != nil {
        go ReadyNotify(&(b.Ready), false)
        fmt.Println(e)
        return e
    }
    rpc.HandleHTTP()
    s, e := net.Listen("tcp", b.Addr)
    if e != nil {
        go ReadyNotify(&(b.Ready), false)
        fmt.Println(e)
        return e
    }
    go ReadyNotify(&(b.Ready), true)
    http.Serve(s, nil)
    return nil
}

func ReadyNotify(c *chan<- bool, b bool) {
    if c != nil {
        *c <- b
    }
}
