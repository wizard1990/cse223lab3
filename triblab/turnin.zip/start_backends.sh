kv-server -addr localhost:10000
kv-server -addr localhost:10001
kv-server -addr localhost:10002
kv-server -addr localhost:10003
